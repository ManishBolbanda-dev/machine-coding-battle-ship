package com.mb.battlefield.model;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class BattleFiled {
	private final int size; //N from input
	private final Map<Player, List<Ship>> playerToShipMap;	
	
}
