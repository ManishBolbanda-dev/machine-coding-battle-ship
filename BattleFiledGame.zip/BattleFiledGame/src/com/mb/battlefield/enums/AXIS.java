package com.mb.battlefield.enums;

public enum AXIS {
	X,
	Y;
}
