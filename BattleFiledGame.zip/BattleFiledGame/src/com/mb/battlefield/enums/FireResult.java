package com.mb.battlefield.enums;

public enum FireResult {
	HIT,
	MISS;
}
