package com.mb.battlefield.exception;

public class PositionOutOfFieldException extends Exception{
	public PositionOutOfFieldException(String msg) {
		super(msg);
	}
}
