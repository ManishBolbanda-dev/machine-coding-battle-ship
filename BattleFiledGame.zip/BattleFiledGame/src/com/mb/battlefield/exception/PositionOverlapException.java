package com.mb.battlefield.exception;

public class PositionOverlapException extends Exception {
	public PositionOverlapException(String msg) {
		super(msg);
	}
}
