package com.mb.battlefield.exception;

public class PositionOutOfBoundException extends Exception{
	public PositionOutOfBoundException(String msg) {
		super(msg);
	}
	
}
